#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "makeup_options.h"

// Function to add a makeup product
void addMakeupProduct(struct MakeupProduct products[], int *count) {
    char priceStr[50];
    printf("\nEnter makeup product information:\n");
    printf("Name: ");
    fgets(products[*count].name, 50, stdin);
    products[*count].name[strcspn(products[*count].name, "\n")] = 0;  // remove trailing newline
    printf("Price: ");
    fgets(priceStr, 50, stdin);
    products[*count].price = atof(priceStr);  // convert string to float
    printf("Usage: ");
    fgets(products[*count].usage, 100, stdin);
    products[*count].usage[strcspn(products[*count].usage, "\n")] = 0;  // remove trailing newline
    
    (*count)++;
}


// Function to view all makeup product records
void viewMakeupProductRecords(const struct MakeupProduct products[], int count) {
    printf("\nMakeup Product Records:\n");
    for (int i = 0; i < count; i++) {
        printf("Name: %s, Price: $%.2f, Usage: %s\n", products[i].name, products[i].price, products[i].usage);
    }
}

// Function to save makeup product records to a file
void saveToFile(const struct MakeupProduct products[], int count) {
    FILE *file = fopen("2207010.txt", "w");

    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return;
    }

    for (int i = 0; i < count; i++) {
        fprintf(file, "%s %.2f %s\n", products[i].name, products[i].price, products[i].usage);
    }

    fclose(file);
    printf("Makeup product records saved to file.\n");
}

// Function to search for a specific makeup product
void searchForMakeupProduct(const struct MakeupProduct products[], int count) {
    char searchName[50];
    printf("\nEnter the name of the makeup product to search: ");
    fgets(searchName, 50, stdin);
    searchName[strcspn(searchName, "\n")] = 0;  // remove trailing newline

    for (int i = 0; i < count; i++) {
        if (strcmp(products[i].name, searchName) == 0) {
            printf("Found: Name: %s, Price: $%.2f, Usage: %s\n", products[i].name, products[i].price, products[i].usage);
            return;
        }
    }

    printf("Makeup product not found.\n");
}

// Function to edit makeup product records
void editMakeupProductRecords(struct MakeupProduct products[], int count) {
    char editName[50];
    printf("\nEnter the name of the makeup product to edit: ");
    fgets(editName, 50, stdin);
    editName[strcspn(editName, "\n")] = 0;  // remove trailing newline

    for (int i = 0; i < count; i++) {
        if (strcmp(products[i].name, editName) == 0) {
            printf("Enter new price for %s: $", products[i].name);
            scanf("%f", &products[i].price);
            getchar();  // consume newline left by scanf
            printf("Enter new usage for %s: ", products[i].name);
            fgets(products[i].usage, 100, stdin);
            products[i].usage[strcspn(products[i].usage, "\n")] = 0;  // remove trailing newline
            printf("Makeup product record updated.\n");
            return;
        }
    }

    printf("Makeup product not found.\n");
}
