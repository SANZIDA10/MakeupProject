#ifndef MAKEUP_OPTIONS_H
#define MAKEUP_OPTIONS_H

struct MakeupProduct {
    char name[50];
    float price;
    char usage[100];
};

void addMakeupProduct(struct MakeupProduct products[], int *count);
void viewMakeupProductRecords(const struct MakeupProduct products[], int count);
void saveToFile(const struct MakeupProduct products[], int count);
void searchForMakeupProduct(const struct MakeupProduct products[], int count);
void editMakeupProductRecords(struct MakeupProduct products[], int count);

#endif  // MAKEUP_OPTIONS_H
