#include <stdio.h>
#include "makeup_options.h"

int main() {
    struct MakeupProduct products[100];  // Assuming a maximum of 100 makeup products
    int count = 0;
    int choice;

    do {
        // Display menu
        printf("\nMakeup Product Information Management System Menu\n");
        printf("1. Add Makeup Product\n");
        printf("2. View Makeup Product Records\n");
        printf("3. Save to File\n");
        printf("4. Search for a Makeup Product\n");
        printf("5. Edit Makeup Product Records\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar();  // consume newline left by scanf

        switch (choice) {
            case 1:
                addMakeupProduct(products, &count);
                break;
            case 2:
                viewMakeupProductRecords(products, count);
                break;
            case 3:
                saveToFile(products, count);
                break;
            case 4:
                searchForMakeupProduct(products, count);
                break;
            case 5:
                editMakeupProductRecords(products, count);
                break;
            case 6:
                printf("Exiting program. Goodbye!\n");
                break;
            default:
                printf("Invalid choice. Please enter a valid option.\n");
        }

    } while (choice != 6);

    return 0;
}

